import java.util.Scanner;

class PetStore {
    public static void main(String[] args) {
        System.out.println("Petstore v1.0");

        Scanner myPet = new Scanner(System.in);  // Create a Scanner object
        System.out.println("Select Pet (Dog, Cat, Fish, Bird): ");
        String myPetStr = myPet.nextLine();  // Read user input

        Scanner myBreed = new Scanner(System.in);  // Create a Scanner object

        if (myPetStr.contentEquals("Dog")) {
            System.out.println("Select Breed (Bulldog, Poodle, Golden Retriever, Labrador): ");
        } else if (myPetStr.contentEquals("Cat")) {
            System.out.println("Select Breed (Manx, Persian): ");
        } else if (myPetStr.contentEquals("Fish")) {
            System.out.println("Select Breed (Angel Fish, Tiger Shark, Koi, Goldfish): ");
        } else if (myPetStr.contentEquals("Bird")) {
            System.out.println("Select Breed (Amazon Parrot, Finch):");
        } else {
            System.out.println("Not Existing Pet");
            return;
        }

        String myBreedStr = myBreed.nextLine();  // Read user input

        System.out.println("Item ID     Product ID     Description   List Price");

        if (myPetStr.contentEquals("Dog")) {
            if (myBreedStr.contentEquals("Bulldog")) {
                System.out.println("EST-1    K9-BD-01    Male Adult Bulldog    $18.50");
                System.out.println("EST-2    K9-BD-01    Male Adult Bulldog    $18.50");
            } else if (myBreedStr.contentEquals("Poodle")) {
                System.out.println("EST-3    K9-PO-02    Male Puppy Poodle    $18.50");
            } else if (myBreedStr.contentEquals("Golden Retriever")) {
                System.out.println("EST-4    K9-RT-01    Adult Female Golden Retriever    $155.29");
            } else if (myBreedStr.contentEquals("Labrador")) {
                System.out.println("EST-5    EST-22    K9-RT-02    Adult Male Labrador Retriever    $135.50");
                System.out.println("EST-6    K9-RT-02    Adult Male Labrador Retriever    $255.50");
                System.out.println("EST-7    K9-RT-02    Adult Female Labrador Retriever    $145.49");
                System.out.println("EST-8    K9-RT-02    Adult Female Labrador Retriever    $325.29");
            } else {
                System.out.print("INVALID BREED");
            }
        } else if (myPetStr.contentEquals("Cat")) {
            if (myBreedStr.contentEquals("Manx")) {
                System.out.println("EST-1    FL-DSH-01    Tailless Manx    $58.50");
                System.out.println("EST-2    FL-DSH-01    With tail Manx    $23.50");
            } else if (myBreedStr.contentEquals("Persian")) {
                System.out.println("EST-3    FL-DLH-02    Adult Male Persian    $93.50");
            } else {
                System.out.println("INVALID BREED");
            }
        } else if (myPetStr.contentEquals("Fish")) {
            if (myBreedStr.contentEquals("Angel Fish")) {
                System.out.println("EST-1    FI-SW-01    Large Angelfish    $16.50");
                System.out.println("EST-2    FI-SW-01    Small Angelfish    $16.50");
            } else if (myBreedStr.contentEquals("Tiger Shark")) {
                System.out.println("EST-3    FI-SW-02    Toothless Tiger Shark    $18.50");
            } else if (myBreedStr.contentEquals("Koi")) {
                System.out.println("EST-4    FI-FW-01    Spotted Koi    $18.50");
                System.out.println("EST-5    FI-FW-01    Spotless Koi    $18.50");
            } else if (myBreedStr.contentEquals("Goldfish")) {
                System.out.println("EST-6    FI-FW-02    Adult Male Goldfish    $5.50");
                System.out.println("EST-7    FI-FW-02    Adult Female Goldfish    $5.29");
            } else {
                System.out.println("INVALID BREED");
            }
        } else if (myPetStr.contentEquals("Bird")) {
            if (myBreedStr.contentEquals("Amazon Parrot")) {
                System.out.println("EST-1    AV-CB-01    Adult Male Amazon Parrot    $193.50");
            } else if (myBreedStr.contentEquals("Finch")) {
                System.out.println("EST-19    AV-SB-02    Adult Male Finch    $15.50");
            } else {
                System.out.println("INVALID BREED");
            }
        }
    }
}
